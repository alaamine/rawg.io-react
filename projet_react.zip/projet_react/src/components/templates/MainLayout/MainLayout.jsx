import { Outlet } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Navbar from '../../organisms/Navbar/Navbar';
import styles from './MainLayout.module.css';

const MainLayout = () => (
  <>
    <a href="#main-content" className="skip-link">Aller au contenu principal</a>
    <Navbar />
    <main id="main-content" className={styles.main}>
      <Outlet />
    </main>
    <footer className={styles.footer}>
      <p>Propulsé par <a href="https://rawg.io" target="_blank" rel="noopener noreferrer">RAWG.io</a></p>
    </footer>
    <ToastContainer
      position="bottom-right"
      autoClose={2500}
      hideProgressBar={false}
      newestOnTop
      closeOnClick
      pauseOnHover
      theme="dark"
    />
  </>
);

export default MainLayout;
