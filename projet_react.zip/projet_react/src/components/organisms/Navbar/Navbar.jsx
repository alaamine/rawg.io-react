import { NavLink } from 'react-router-dom';
import { useFavorites } from '../../../context/FavoritesContext';
import styles from './Navbar.module.css';

const Navbar = () => {
  const { favorites } = useFavorites();

  return (
    <header className={styles.header}>
      <nav className={styles.nav} aria-label="Navigation principale">
        <NavLink to="/" className={styles.logo} aria-label="Accueil RAWG Explorer">
          <span className={styles.logoIcon}>◈</span>
          <span className={styles.logoText}>RAWG<span className={styles.logoAccent}>.</span>IO</span>
        </NavLink>

        <ul className={styles.links} role="list">
          <li>
            <NavLink
              to="/games"
              className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
            >
              Jeux
            </NavLink>
          </li>
          <li>
            <NavLink
              to="/favorites"
              className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
              aria-label={`Favoris (${favorites.length} jeux)`}
            >
              Favoris
              {favorites.length > 0 && (
                <span className={styles.badge} aria-hidden="true">{favorites.length}</span>
              )}
            </NavLink>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default Navbar;
