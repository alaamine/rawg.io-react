import Spinner from '../../atoms/Spinner/Spinner';
import GameCard from '../../molecules/GameCard/GameCard';
import styles from './GameGrid.module.css';

const GameGrid = ({ games, loading, error, sentinelRef, hasMore }) => {
  if (error) {
    return (
      <div className={styles.state} role="alert">
        <p className={styles.error}>⚠ Une erreur est survenue : {error}</p>
      </div>
    );
  }

  return (
    <section aria-label="Liste des jeux">
      {games.length === 0 && !loading && (
        <div className={styles.state}>
          <p className={styles.empty}>Aucun jeu trouvé pour ces filtres.</p>
        </div>
      )}
      <ul className={styles.grid} role="list">
        {games.map((game) => (
          <li key={game.id}>
            <GameCard game={game} />
          </li>
        ))}
      </ul>
      <div ref={sentinelRef} className={styles.sentinel} aria-hidden="true" />
      {loading && (
        <div className={styles.loadingRow}>
          <Spinner size="md" label="Chargement des jeux…" />
        </div>
      )}
      {!hasMore && games.length > 0 && (
        <p className={styles.end}>— Fin des résultats —</p>
      )}
    </section>
  );
};

export default GameGrid;
