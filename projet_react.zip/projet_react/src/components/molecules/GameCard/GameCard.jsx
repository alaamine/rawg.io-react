import { Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import { useFavorites } from '../../../context/FavoritesContext';
import Badge from '../../atoms/Badge/Badge';
import Rating from '../../atoms/Rating/Rating';
import styles from './GameCard.module.css';

const PLACEHOLDER = 'https://via.placeholder.com/400x225?text=No+Image';

const GameCard = ({ game }) => {
  const { isFavorite, addFavorite, removeFavorite } = useFavorites();
  const fav = isFavorite(game.id);

  const toggleFav = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (fav) {
      removeFavorite(game.id);
      toast.info(`"${game.name}" retiré des favoris`);
    } else {
      addFavorite({
        id: game.id,
        name: game.name,
        background_image: game.background_image,
        rating: game.rating,
        platforms: game.platforms,
        released: game.released,
      });
      toast.success(`"${game.name}" ajouté aux favoris`);
    }
  };

  return (
    <article className={styles.card} data-testid="game-card">
      <Link to={`/games/${game.id}`} className={styles.inner} aria-label={`Voir les détails de ${game.name}`}>
        <div className={styles.imageWrap}>
          <img
            src={game.background_image || PLACEHOLDER}
            alt={`Illustration du jeu ${game.name}`}
            className={styles.image}
            loading="lazy"
          />
          <div className={styles.overlay} />
          {game.metacritic && (
            <span
              className={styles.metacritic}
              aria-label={`Score Metacritic: ${game.metacritic}`}
            >
              {game.metacritic}
            </span>
          )}
        </div>
        <div className={styles.body}>
          <div className={styles.platforms}>
            {game.platforms?.slice(0, 4).map((p) => (
              <Badge key={p.platform.id} variant="platform">
                {p.platform.name}
              </Badge>
            ))}
          </div>
          <h2 className={styles.title}>{game.name}</h2>
          <div className={styles.meta}>
            {game.released && (
              <span className={styles.date}>
                {new Date(game.released).toLocaleDateString('fr-FR', {
                  year: 'numeric',
                  month: 'short',
                })}
              </span>
            )}
            <Rating rating={game.rating} />
          </div>
        </div>
      </Link>
      <button
        className={`${styles.favBtn} ${fav ? styles.active : ''}`}
        onClick={toggleFav}
        aria-label={fav ? `Retirer ${game.name} des favoris` : `Ajouter ${game.name} aux favoris`}
        aria-pressed={fav}
      >
        {fav ? '♥' : '♡'}
      </button>
    </article>
  );
};

export default GameCard;
