import { useEffect, useState } from 'react';
import { getPlatforms, getStores } from '../../../api/rawg';
import styles from './FilterBar.module.css';

const SORT_OPTIONS = [
  { value: '', label: 'Par défaut' },
  { value: '-added', label: 'Popularité' },
  { value: '-rating', label: 'Note' },
  { value: '-released', label: 'Date de sortie' },
  { value: '-metacritic', label: 'Metacritic' },
  { value: 'name', label: 'Nom (A-Z)' },
  { value: '-name', label: 'Nom (Z-A)' },
];

const FilterBar = ({ onFilterChange }) => {
  const [platforms, setPlatforms] = useState([]);
  const [stores, setStores] = useState([]);
  const [selected, setSelected] = useState({ platform: '', store: '', ordering: '' });
  const [search, setSearch] = useState('');

  useEffect(() => {
    getPlatforms({ page_size: 20 }).then((d) => setPlatforms(d.results));
    getStores().then((d) => setStores(d.results));
  }, []);

  const handleChange = (key, value) => {
    const next = { ...selected, [key]: value };
    setSelected(next);
    onFilterChange({ ...next, search });
  };

  const handleSearch = (e) => {
    if (e.key === 'Enter') {
      onFilterChange({ ...selected, search: e.target.value });
    }
    setSearch(e.target.value);
  };

  const reset = () => {
    setSelected({ platform: '', store: '', ordering: '' });
    setSearch('');
    onFilterChange({ platform: '', store: '', ordering: '', search: '' });
  };

  const hasFilters = selected.platform || selected.store || selected.ordering || search;

  return (
    <section className={styles.bar} aria-label="Filtres et tri">
      <div className={styles.searchWrap}>
        <label htmlFor="game-search" className={styles.srOnly}>Rechercher un jeu</label>
        <input
          id="game-search"
          type="search"
          className={styles.search}
          placeholder="Rechercher un jeu…"
          value={search}
          onChange={handleSearch}
          onKeyDown={(e) => {
            if (e.key === 'Enter') onFilterChange({ ...selected, search });
          }}
        />
        <span className={styles.searchIcon} aria-hidden="true">⌕</span>
      </div>

      <div className={styles.filters}>
        <div className={styles.selectWrap}>
          <label htmlFor="filter-platform" className={styles.srOnly}>Plateforme</label>
          <select
            id="filter-platform"
            className={styles.select}
            value={selected.platform}
            onChange={(e) => handleChange('platform', e.target.value)}
          >
            <option value="">Toutes les plateformes</option>
            {platforms.map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        </div>

        <div className={styles.selectWrap}>
          <label htmlFor="filter-store" className={styles.srOnly}>Store</label>
          <select
            id="filter-store"
            className={styles.select}
            value={selected.store}
            onChange={(e) => handleChange('store', e.target.value)}
          >
            <option value="">Tous les stores</option>
            {stores.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>

        <div className={styles.selectWrap}>
          <label htmlFor="filter-sort" className={styles.srOnly}>Trier par</label>
          <select
            id="filter-sort"
            className={styles.select}
            value={selected.ordering}
            onChange={(e) => handleChange('ordering', e.target.value)}
          >
            {SORT_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        </div>

        {hasFilters && (
          <button className={styles.resetBtn} onClick={reset} aria-label="Réinitialiser les filtres">
            ✕ Réinitialiser
          </button>
        )}
      </div>
    </section>
  );
};

export default FilterBar;
