import styles from './AchievementItem.module.css';

const AchievementItem = ({ achievement }) => {
  const pct = achievement.percent ? parseFloat(achievement.percent).toFixed(1) : 0;
  return (
    <li className={styles.item}>
      <div className={styles.header}>
        {achievement.image && (
          <img
            src={achievement.image}
            alt=""
            className={styles.icon}
            aria-hidden="true"
          />
        )}
        <div className={styles.info}>
          <span className={styles.name}>{achievement.name}</span>
          {achievement.description && (
            <span className={styles.desc}>{achievement.description}</span>
          )}
        </div>
        <span className={styles.pct} aria-label={`${pct}% des joueurs ont débloqué ce succès`}>
          {pct}%
        </span>
      </div>
      <div
        className={styles.bar}
        role="meter"
        aria-valuenow={parseFloat(pct)}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={`Progression: ${pct}%`}
      >
        <div className={styles.fill} style={{ width: `${pct}%` }} />
      </div>
    </li>
  );
};

export default AchievementItem;
