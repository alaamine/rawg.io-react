import styles from './Rating.module.css';

const Rating = ({ rating, ratingsCount }) => {
  if (!rating) return null;
  const pct = (rating / 5) * 100;
  return (
    <div className={styles.wrapper} aria-label={`Note: ${rating} sur 5`}>
      <div className={styles.bar} role="meter" aria-valuenow={rating} aria-valuemin={0} aria-valuemax={5}>
        <div className={styles.fill} style={{ width: `${pct}%` }} />
      </div>
      <span className={styles.value}>{rating.toFixed(1)}</span>
      {ratingsCount && <span className={styles.count}>({ratingsCount.toLocaleString()})</span>}
    </div>
  );
};

export default Rating;
