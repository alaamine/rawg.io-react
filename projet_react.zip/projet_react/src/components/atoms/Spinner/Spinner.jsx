import styles from './Spinner.module.css';

const Spinner = ({ size = 'md', label = 'Chargement…' }) => (
  <div className={`${styles.spinner} ${styles[size]}`} role="status" aria-label={label}>
    <span className={styles.sr}>Chargement…</span>
  </div>
);

export default Spinner;
