import { createContext, useContext, useEffect, useReducer } from 'react';

const FavoritesContext = createContext(null);

const STORAGE_KEY = 'rawg_favorites';

const loadFromStorage = () => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
};

const saveToStorage = (favorites) => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(favorites));
  } catch {
    // Silently fail if storage is unavailable
  }
};

const favoritesReducer = (state, action) => {
  switch (action.type) {
    case 'ADD': {
      if (state.find((g) => g.id === action.payload.id)) return state;
      return [...state, action.payload];
    }
    case 'REMOVE':
      return state.filter((g) => g.id !== action.payload);
    default:
      return state;
  }
};

export const FavoritesProvider = ({ children }) => {
  const [favorites, dispatch] = useReducer(favoritesReducer, [], loadFromStorage);

  useEffect(() => {
    saveToStorage(favorites);
  }, [favorites]);

  const addFavorite = (game) => dispatch({ type: 'ADD', payload: game });
  const removeFavorite = (id) => dispatch({ type: 'REMOVE', payload: id });
  const isFavorite = (id) => favorites.some((g) => g.id === id);

  return (
    <FavoritesContext.Provider value={{ favorites, addFavorite, removeFavorite, isFavorite }}>
      {children}
    </FavoritesContext.Provider>
  );
};

export const useFavorites = () => {
  const ctx = useContext(FavoritesContext);
  if (!ctx) throw new Error('useFavorites must be used inside FavoritesProvider');
  return ctx;
};
