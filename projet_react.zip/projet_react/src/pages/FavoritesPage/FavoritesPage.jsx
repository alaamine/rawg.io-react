import { Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import Badge from '../../components/atoms/Badge/Badge';
import Button from '../../components/atoms/Button/Button';
import Rating from '../../components/atoms/Rating/Rating';
import { useFavorites } from '../../context/FavoritesContext';
import styles from './FavoritesPage.module.css';

const FavoritesPage = () => {
  const { favorites, removeFavorite } = useFavorites();

  const handleRemove = (game) => {
    removeFavorite(game.id);
    toast.info(`"${game.name}" retiré des favoris`);
  };

  return (
    <div className={styles.page}>
      <div className={styles.hero}>
        <h1 className={styles.title}>Mes Favoris</h1>
        <p className={styles.sub}>
          {favorites.length === 0
            ? "Aucun favori pour l'instant."
            : `${favorites.length} jeu${favorites.length > 1 ? 'x' : ''} sauvegardé${favorites.length > 1 ? 's' : ''}`}
        </p>
      </div>

      {favorites.length === 0 ? (
        <div className={styles.empty}>
          <p className={styles.emptyText}>♡ Explorez les jeux et ajoutez-en à vos favoris !</p>
          <Link to="/games">
            <Button variant="primary">Explorer les jeux</Button>
          </Link>
        </div>
      ) : (
        <ul className={styles.list} aria-label="Liste des jeux favoris">
          {favorites.map((game) => (
            <li key={game.id} className={styles.item}>
              <Link to={`/games/${game.id}`} className={styles.itemLink} aria-label={`Voir les détails de ${game.name}`}>
                <div className={styles.imageWrap}>
                  <img
                    src={game.background_image || '/placeholder.png'}
                    alt={`Illustration de ${game.name}`}
                    className={styles.image}
                    loading="lazy"
                  />
                </div>
                <div className={styles.info}>
                  <h2 className={styles.gameName}>{game.name}</h2>
                  {game.released && (
                    <span className={styles.date}>
                      {new Date(game.released).toLocaleDateString('fr-FR', {
                        year: 'numeric', month: 'long', day: 'numeric',
                      })}
                    </span>
                  )}
                  <div className={styles.platforms}>
                    {game.platforms?.slice(0, 3).map((p) => (
                      <Badge key={p.platform.id} variant="platform">{p.platform.name}</Badge>
                    ))}
                  </div>
                  <Rating rating={game.rating} />
                </div>
              </Link>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleRemove(game)}
                aria-label={`Retirer ${game.name} des favoris`}
                className={styles.removeBtn}
              >
                ✕
              </Button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default FavoritesPage;
