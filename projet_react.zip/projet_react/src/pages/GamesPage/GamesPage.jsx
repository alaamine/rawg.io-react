import { useCallback, useState } from 'react';
import FilterBar from '../../components/molecules/FilterBar/FilterBar';
import GameGrid from '../../components/organisms/GameGrid/GameGrid';
import { useGames } from '../../hooks/useGames';
import { useInfiniteScroll } from '../../hooks/useInfiniteScroll';
import styles from './GamesPage.module.css';

const GamesPage = () => {
  const [filters, setFilters] = useState({});

  const handleFilterChange = useCallback((newFilters) => {
    const mapped = {};
    if (newFilters.platform) mapped.platforms = newFilters.platform;
    if (newFilters.store) mapped.stores = newFilters.store;
    if (newFilters.ordering) mapped.ordering = newFilters.ordering;
    if (newFilters.search) mapped.search = newFilters.search;
    setFilters(mapped);
  }, []);

  const { games, loading, error, hasMore, loadMore } = useGames(filters);
  const sentinelRef = useInfiniteScroll(loadMore, hasMore);

  return (
    <div className={styles.page}>
      <div className={styles.hero}>
        <h1 className={styles.title}>Explorer les jeux</h1>
        <p className={styles.sub}>
          {Object.keys(filters).length > 0
            ? 'Résultats filtrés'
            : 'Découvrez des milliers de jeux vidéo'}
        </p>
      </div>
      <FilterBar onFilterChange={handleFilterChange} />
      <GameGrid
        games={games}
        loading={loading}
        error={error}
        sentinelRef={sentinelRef}
        hasMore={hasMore}
      />
    </div>
  );
};

export default GamesPage;
