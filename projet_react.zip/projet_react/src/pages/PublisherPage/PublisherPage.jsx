import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getPublisher } from '../../api/rawg';
import Spinner from '../../components/atoms/Spinner/Spinner';
import GameGrid from '../../components/organisms/GameGrid/GameGrid';
import { useGames } from '../../hooks/useGames';
import { useInfiniteScroll } from '../../hooks/useInfiniteScroll';
import styles from './PublisherPage.module.css';

const PublisherPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [publisher, setPublisher] = useState(null);
  const [pubLoading, setPubLoading] = useState(true);

  const gamesFilters = useMemo(() => ({ publishers: id }), [id]);

  const { games, loading, error, hasMore, loadMore } = useGames(gamesFilters);
  const sentinelRef = useInfiniteScroll(loadMore, hasMore);

  useEffect(() => {
    setPubLoading(true);
    getPublisher(id)
      .then(setPublisher)
      .catch((err) => {
        if (err.isNotFound) navigate('/not-found', { replace: true });
      })
      .finally(() => setPubLoading(false));
  }, [id, navigate]);

  if (pubLoading) {
    return (
      <div className={styles.center}>
        <Spinner size="lg" />
      </div>
    );
  }

  return (
    <div className={styles.page}>
      <div className={styles.header}>
        {publisher?.image_background && (
          <img src={publisher.image_background} alt="" className={styles.headerBg} aria-hidden="true" />
        )}
        <div className={styles.headerOverlay} />
        <div className={styles.headerContent}>
          <p className={styles.label}>Éditeur</p>
          <h1 className={styles.title}>{publisher?.name || 'Éditeur'}</h1>
          {publisher?.games_count && (
            <p className={styles.count}>{publisher.games_count.toLocaleString()} jeux</p>
          )}
        </div>
      </div>

      <GameGrid
        games={games}
        loading={loading}
        error={error}
        sentinelRef={sentinelRef}
        hasMore={hasMore}
      />
    </div>
  );
};

export default PublisherPage;
