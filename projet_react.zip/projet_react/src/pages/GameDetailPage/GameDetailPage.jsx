import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { toast } from 'react-toastify';
import {
  getGameAchievements,
  getGameDetail,
  getGameScreenshots,
  getGameTrailers,
} from '../../api/rawg';
import Badge from '../../components/atoms/Badge/Badge';
import Spinner from '../../components/atoms/Spinner/Spinner';
import AchievementItem from '../../components/molecules/AchievementItem/AchievementItem';
import { useFavorites } from '../../context/FavoritesContext';
import styles from './GameDetailPage.module.css';

const GameDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isFavorite, addFavorite, removeFavorite } = useFavorites();

  const [game, setGame] = useState(null);
  const [trailers, setTrailers] = useState([]);
  const [achievements, setAchievements] = useState([]);
  const [screenshots, setScreenshots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    setLoading(true);
    setError(null);
    Promise.all([
      getGameDetail(id),
      getGameTrailers(id).catch(() => ({ results: [] })),
      getGameAchievements(id).catch(() => ({ results: [] })),
      getGameScreenshots(id).catch(() => ({ results: [] })),
    ])
      .then(([g, t, a, s]) => {
        setGame(g);
        setTrailers(t.results || []);
        setAchievements(a.results || []);
        setScreenshots(s.results || []);
      })
      .catch((err) => {
        if (err.isNotFound) navigate('/not-found', { replace: true });
        else setError(err.message);
      })
      .finally(() => setLoading(false));
  }, [id, navigate]);

  const toggleFav = () => {
    if (!game) return;
    if (isFavorite(game.id)) {
      removeFavorite(game.id);
      toast.info(`"${game.name}" retiré des favoris`);
    } else {
      addFavorite({
        id: game.id,
        name: game.name,
        background_image: game.background_image,
        rating: game.rating,
        platforms: game.platforms,
        released: game.released,
      });
      toast.success(`"${game.name}" ajouté aux favoris`);
    }
  };

  if (loading) {
    return (
      <div className={styles.center}>
        <Spinner size="lg" label="Chargement du jeu…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles.center} role="alert">
        <p className={styles.errorMsg}>⚠ {error}</p>
      </div>
    );
  }

  if (!game) return null;

  const fav = isFavorite(game.id);

  return (
    <article className={styles.page}>
      {/* Hero */}
      <div className={styles.hero}>
        {game.background_image && (
          <img src={game.background_image} alt="" className={styles.heroBg} aria-hidden="true" />
        )}
        <div className={styles.heroOverlay} />
        <div className={styles.heroContent}>
          <nav aria-label="Fil d'ariane">
            <ol className={styles.breadcrumb}>
              <li><Link to="/games">Jeux</Link></li>
              <li aria-current="page">{game.name}</li>
            </ol>
          </nav>
          <h1 className={styles.title}>{game.name}</h1>
          <div className={styles.metaRow}>
            {game.released && (
              <span className={styles.released}>
                {new Date(game.released).toLocaleDateString('fr-FR', {
                  day: 'numeric', month: 'long', year: 'numeric',
                })}
              </span>
            )}
            {game.metacritic && (
              <span className={styles.metacritic} aria-label={`Score Metacritic: ${game.metacritic}`}>
                MC {game.metacritic}
              </span>
            )}
          </div>
          <button
            className={`${styles.favBtn} ${fav ? styles.favActive : ''}`}
            onClick={toggleFav}
            aria-label={fav ? 'Retirer des favoris' : 'Ajouter aux favoris'}
            aria-pressed={fav}
          >
            {fav ? '♥ Dans les favoris' : '♡ Ajouter aux favoris'}
          </button>
        </div>
      </div>

      <div className={styles.content}>
        {/* Main column */}
        <div className={styles.main}>
          {/* Trailer */}
          {trailers.length > 0 && (
            <section className={styles.section} aria-label="Trailer">
              <h2 className={styles.sectionTitle}>Trailer</h2>
              <video
                controls
                poster={trailers[0].preview}
                className={styles.video}
                aria-label={`Trailer de ${game.name}`}
              >
                <source src={trailers[0].data?.max} type="video/mp4" />
                <source src={trailers[0].data?.['480']} type="video/mp4" />
                Votre navigateur ne supporte pas la lecture de vidéo.
              </video>
            </section>
          )}

          {/* Description */}
          {game.description_raw && (
            <section className={styles.section} aria-label="Description">
              <h2 className={styles.sectionTitle}>Description</h2>
              <p className={styles.description}>{game.description_raw}</p>
            </section>
          )}

          {/* Screenshots */}
          {screenshots.length > 0 && (
            <section className={styles.section} aria-label="Captures d'écran">
              <h2 className={styles.sectionTitle}>Captures d'écran</h2>
              <div className={styles.screenshots}>
                {screenshots.slice(0, 6).map((s) => (
                  <img key={s.id} src={s.image} alt={`Capture d'écran de ${game.name}`} className={styles.screenshot} loading="lazy" />
                ))}
              </div>
            </section>
          )}

          {/* Achievements */}
          {achievements.length > 0 && (
            <section className={styles.section} aria-label="Succès / Trophées">
              <h2 className={styles.sectionTitle}>Succès ({achievements.length})</h2>
              <ul className={styles.achievements} aria-label="Liste des succès">
                {achievements.slice(0, 10).map((a) => (
                  <AchievementItem key={a.id} achievement={a} />
                ))}
              </ul>
            </section>
          )}
        </div>

        {/* Sidebar */}
        <aside className={styles.sidebar} aria-label="Informations du jeu">
          {/* Platforms */}
          {game.platforms?.length > 0 && (
            <div className={styles.infoBlock}>
              <h3 className={styles.infoTitle}>Plateformes</h3>
              <div className={styles.tags}>
                {game.platforms.map((p) => (
                  <Badge key={p.platform.id} variant="platform">{p.platform.name}</Badge>
                ))}
              </div>
            </div>
          )}

          {/* Tags */}
          {game.tags?.length > 0 && (
            <div className={styles.infoBlock}>
              <h3 className={styles.infoTitle}>Tags</h3>
              <div className={styles.tags}>
                {game.tags.slice(0, 12).map((t) => (
                  <Badge key={t.id}>{t.name}</Badge>
                ))}
              </div>
            </div>
          )}

          {/* Publishers */}
          {game.publishers?.length > 0 && (
            <div className={styles.infoBlock}>
              <h3 className={styles.infoTitle}>Éditeurs</h3>
              <ul className={styles.publisherList}>
                {game.publishers.map((p) => (
                  <li key={p.id}>
                    <Link to={`/publisher/${p.id}`} className={styles.publisherLink}>
                      {p.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Developers */}
          {game.developers?.length > 0 && (
            <div className={styles.infoBlock}>
              <h3 className={styles.infoTitle}>Développeurs</h3>
              <div className={styles.tags}>
                {game.developers.map((d) => (
                  <Badge key={d.id} variant="accent">{d.name}</Badge>
                ))}
              </div>
            </div>
          )}

          {/* Genres */}
          {game.genres?.length > 0 && (
            <div className={styles.infoBlock}>
              <h3 className={styles.infoTitle}>Genres</h3>
              <div className={styles.tags}>
                {game.genres.map((g) => (
                  <Badge key={g.id} variant="success">{g.name}</Badge>
                ))}
              </div>
            </div>
          )}

          {game.website && (
            <div className={styles.infoBlock}>
              <h3 className={styles.infoTitle}>Site officiel</h3>
              <a href={game.website} target="_blank" rel="noopener noreferrer" className={styles.websiteLink}>
                Visiter le site ↗
              </a>
            </div>
          )}
        </aside>
      </div>
    </article>
  );
};

export default GameDetailPage;
