import { Link } from 'react-router-dom';
import Button from '../../components/atoms/Button/Button';
import styles from './NotFoundPage.module.css';

const NotFoundPage = () => (
  <div className={styles.page} role="main" aria-labelledby="not-found-title">
    <div className={styles.glitch} aria-hidden="true">404</div>
    <h1 id="not-found-title" className={styles.title}>Page introuvable</h1>
    <p className={styles.sub}>
      Cette page n'existe pas ou le jeu demandé est introuvable.
    </p>
    <Link to="/">
      <Button variant="primary" size="lg">← Retour à l'accueil</Button>
    </Link>
  </div>
);

export default NotFoundPage;
