import axios from 'axios';

const apiClient = axios.create({
  baseURL: '/api',
  timeout: 10000,
});

// Request interceptor: inject API key on every request
apiClient.interceptors.request.use(
  (config) => {
    config.params = {
      ...config.params,
      key: import.meta.env.VITE_RAWG_API_KEY,
    };
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor: global error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 404) {
      error.isNotFound = true;
    }
    return Promise.reject(error);
  }
);

export default apiClient;
