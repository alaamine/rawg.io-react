import apiClient from './axiosInstance';

export const getGames = (params = {}) =>
  apiClient.get('/games', { params }).then((r) => r.data);

export const getGameDetail = (id) =>
  apiClient.get(`/games/${id}`).then((r) => r.data);

export const getGameTrailers = (id) =>
  apiClient.get(`/games/${id}/movies`).then((r) => r.data);

export const getGameAchievements = (id) =>
  apiClient.get(`/games/${id}/achievements`).then((r) => r.data);

export const getGameScreenshots = (id) =>
  apiClient.get(`/games/${id}/screenshots`).then((r) => r.data);

export const getPlatforms = (params = {}) =>
  apiClient.get('/platforms', { params }).then((r) => r.data);

export const getStores = () =>
  apiClient.get('/stores').then((r) => r.data);

export const getPublisher = (id) =>
  apiClient.get(`/publishers/${id}`).then((r) => r.data);

export const getPublisherGames = (id, params = {}) =>
  apiClient.get('/games', { params: { publishers: id, ...params } }).then((r) => r.data);
