import { Navigate, Route, Routes } from 'react-router-dom';
import MainLayout from './components/templates/MainLayout/MainLayout';
import { FavoritesProvider } from './context/FavoritesContext';
import FavoritesPage from './pages/FavoritesPage/FavoritesPage';
import GameDetailPage from './pages/GameDetailPage/GameDetailPage';
import GamesPage from './pages/GamesPage/GamesPage';
import NotFoundPage from './pages/NotFoundPage/NotFoundPage';
import PublisherPage from './pages/PublisherPage/PublisherPage';

function App() {
  return (
    <FavoritesProvider>
      <Routes>
        <Route element={<MainLayout />}>
          <Route path="/" element={<Navigate to="/games" replace />} />
          <Route path="/games" element={<GamesPage />} />
          <Route path="/games/:id" element={<GameDetailPage />} />
          <Route path="/publisher/:id" element={<PublisherPage />} />
          <Route path="/favorites" element={<FavoritesPage />} />
          <Route path="/not-found" element={<NotFoundPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Route>
      </Routes>
    </FavoritesProvider>
  );
}

export default App;
