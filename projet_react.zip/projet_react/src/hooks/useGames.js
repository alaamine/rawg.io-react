import { useCallback, useEffect, useRef, useState } from 'react';
import { getGames } from '../api/rawg';

export const useGames = (filters) => {
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const abortRef = useRef(null);

  const fetchGames = useCallback(
    async (pageNum, reset = false) => {
      if (abortRef.current) abortRef.current.abort();
      abortRef.current = new AbortController();

      setLoading(true);
      setError(null);
      try {
        const params = {
          page: pageNum,
          page_size: 20,
          ...filters,
        };
        // Remove empty params
        Object.keys(params).forEach((k) => {
          if (!params[k]) delete params[k];
        });
        const data = await getGames(params);
        setGames((prev) => (reset ? data.results : [...prev, ...data.results]));
        setHasMore(!!data.next);
      } catch (err) {
        if (err.name !== 'CanceledError') setError(err.message);
      } finally {
        setLoading(false);
      }
    },
    [filters]
  );

  // Reset when filters change
  useEffect(() => {
    setPage(1);
    setGames([]);
    fetchGames(1, true);
  }, [filters, fetchGames]);

  const loadMore = useCallback(() => {
    if (!loading && hasMore) {
      const nextPage = page + 1;
      setPage(nextPage);
      fetchGames(nextPage, false);
    }
  }, [loading, hasMore, page, fetchGames]);

  return { games, loading, error, hasMore, loadMore };
};
