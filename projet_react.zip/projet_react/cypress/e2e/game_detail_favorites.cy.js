/// <reference types="cypress" />

describe('Scénario complet - Détail d'un jeu et gestion des favoris', () => {
  const GAME_ID = 56328; // Grand Theft Auto V - ID imposé par le sujet

  beforeEach(() => {
    // Clear localStorage avant chaque test
    cy.clearLocalStorage();
  });

  it('Affiche la page d'accueil et charge les jeux', () => {
    cy.visit('/');
    cy.url().should('include', '/games');
    cy.get('[data-testid="game-card"]').should('have.length.greaterThan', 0);
    cy.get('h1').should('be.visible');
  });

  it('Permet de filtrer les jeux par plateforme', () => {
    cy.visit('/games');
    cy.get('[data-testid="game-card"]').should('have.length.greaterThan', 0);

    cy.get('#filter-platform').should('be.visible');
    cy.get('#filter-platform').select('4'); // PC

    // Les cartes se rechargent
    cy.get('[data-testid="game-card"]').should('have.length.greaterThan', 0);
  });

  it('Navigue vers la page de détail d'un jeu et affiche les informations', () => {
    cy.visit(`/games/${GAME_ID}`);

    // Le titre est visible
    cy.get('h1').should('be.visible').and('not.be.empty');

    // Les plateformes sont affichées
    cy.get('[aria-label="Informations du jeu"]').should('be.visible');

    // Le bouton favori est présent et accessible
    cy.get('button[aria-label*="favoris"]').should('be.visible');
    cy.get('button[aria-label*="favoris"]').should('have.attr', 'aria-pressed');
  });

  it('Ajoute un jeu aux favoris depuis la page de détail', () => {
    cy.visit(`/games/${GAME_ID}`);

    cy.get('button[aria-label*="Ajouter aux favoris"]').click();

    // Vérifier le toast de confirmation
    cy.contains('ajouté aux favoris').should('be.visible');

    // Vérifier que le bouton indique maintenant "dans les favoris"
    cy.get('button[aria-pressed="true"]').should('be.visible');
  });

  it('Persiste les favoris dans localStorage et les affiche sur la page Favoris', () => {
    cy.visit(`/games/${GAME_ID}`);
    cy.get('button[aria-label*="Ajouter aux favoris"]').click();
    cy.contains('ajouté aux favoris').should('be.visible');

    // Vérification localStorage
    cy.window().then((win) => {
      const stored = JSON.parse(win.localStorage.getItem('rawg_favorites') || '[]');
      expect(stored).to.have.length.greaterThan(0);
      expect(stored[0].id).to.equal(GAME_ID);
    });

    // Navigation vers la page favoris
    cy.get('nav').contains('Favoris').click();
    cy.url().should('include', '/favorites');
    cy.get('[aria-label="Liste des jeux favoris"]').should('be.visible');
    cy.get('li').should('have.length.greaterThan', 0);
  });

  it('Retire un jeu des favoris depuis la page Favoris', () => {
    // Setup : ajouter d'abord un favori
    cy.visit(`/games/${GAME_ID}`);
    cy.get('button[aria-label*="Ajouter aux favoris"]').click();

    // Aller sur la page favoris
    cy.visit('/favorites');
    cy.get('[aria-label="Liste des jeux favoris"]').should('be.visible');

    // Retirer le favori
    cy.get('button[aria-label*="Retirer"]').first().click();
    cy.contains('retiré des favoris').should('be.visible');

    // La liste est vide
    cy.get('.empty, [aria-label="Liste des jeux favoris"] li').should('have.length', 0);
  });

  it('Affiche la page 404 pour une route inexistante', () => {
    cy.visit('/page-qui-nexiste-pas', { failOnStatusCode: false });
    cy.get('#not-found-title').should('be.visible');
    cy.contains('Retour à l'accueil').should('be.visible');
  });

  it('Retourne à l'accueil depuis la page 404', () => {
    cy.visit('/page-qui-nexiste-pas', { failOnStatusCode: false });
    cy.contains('Retour à l'accueil').click();
    cy.url().should('include', '/games');
  });
});
