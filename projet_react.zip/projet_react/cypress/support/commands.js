// Custom Cypress commands
Cypress.Commands.add('addToFavorites', (gameId) => {
  cy.visit(`/games/${gameId}`);
  cy.get('button[aria-label*="Ajouter aux favoris"]').click();
});
