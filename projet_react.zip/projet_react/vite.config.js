import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  const apiKey = env.VITE_RAWG_API_KEY

  return {
    plugins: [react()],
    server: {
      proxy: {
        '/api': {
          target: 'https://api.rawg.io',
          changeOrigin: true,
          configure: (proxy) => {
            proxy.on('proxyReq', (proxyReq, req) => {
              const url = new URL('https://api.rawg.io' + req.url)
              if (!url.searchParams.has('key')) {
                url.searchParams.set('key', apiKey)
                proxyReq.path = url.pathname + '?' + url.searchParams.toString()
              }
            })
          },
        },
      },
    },
  }
})