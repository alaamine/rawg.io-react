# Bonus - Justification des fonctionnalités supplémentaires

## 1. Infinite Scroll (au lieu de la pagination classique)
Implémenté via `IntersectionObserver` dans le hook `useInfiniteScroll`, offrant une expérience fluide et moderne.

## 2. Accessibilité renforcée (WCAG 2.1 AA)
- Lien "skip to content" en début de page
- Tous les boutons ont des `aria-label` explicites
- `aria-pressed` sur les boutons toggle (favoris)
- `role="meter"` sur les barres de progression des succès
- `role="alert"` sur les messages d'erreur
- Fil d'ariane (`breadcrumb`) avec `aria-current="page"`
- Navigation principale avec `aria-label`
- Images décoratives avec `aria-hidden="true"`
- Labels explicites sur tous les inputs via `<label>` associé

## 3. Captures d'écran du jeu
Galerie des screenshots affichée sur la page de détail d'un jeu.

## 4. Annulation des requêtes (AbortController)
Le hook `useGames` annule les requêtes en cours lors d'un changement de filtres pour éviter les race conditions.

## 5. Recherche en temps réel
Champ de recherche intégré à la FilterBar permettant de chercher par nom de jeu.

## 6. Page 404 animée
Animation CSS "glitch" sur le texte 404, sans dépendance externe.

## 7. Scénario Cypress complet (7 tests)
Le scénario couvre : chargement de la liste, filtrage par plateforme, affichage détail, ajout aux favoris, persistance localStorage, suppression des favoris, et navigation 404.

## 8. Architecture Atomic Design stricte
Atoms → Molecules → Organisms → Templates → Pages, chaque composant dans son propre dossier avec CSS Module isolé.
